from pathlib import Path
import pathspec


class SecureliIgnoreService:
    """
    Looks for and translates a local .secureliignore file into a set
    of regular expressions that match the lines given, ignoring comments.
    """

    def ignored_file_patterns(self) -> list[str]:
        """
        Calculate the regular expressions to ignore from .secureliignore, assuming it
        follows the same structure as a .gitignore file
        :return: A list of regular expression pattern strings, or empty array if the
        file is empty or missing.
        """
        secureli_ignore_path = Path("./.secureliignore")
        if not secureli_ignore_path.exists():
            return []

        with open(secureli_ignore_path, "r") as f:
            lines = f.readlines()
            pathspec_lines = pathspec.PathSpec.from_lines(
                pathspec.patterns.GitWildMatchPattern, lines
            )
            raw_patterns = [
                pathspec_pattern.regex.pattern
                for pathspec_pattern in pathspec_lines.patterns
                if pathspec_pattern.include
            ]

            return raw_patterns
