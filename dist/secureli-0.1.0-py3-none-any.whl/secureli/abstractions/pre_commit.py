import subprocess
import hashlib

from pathlib import Path
from typing import Callable, Optional

import pydantic
import yaml

from secureli.patterns import combine_patterns
from secureli.resources.slugify import slugify


class InstallFailedError(Exception):
    """Attempting to invoke pre-commit to set up our repo for the given template did not succeed"""

    pass


class ExecuteFailedError(Exception):
    """Attempting to invoke pre-commit to test our repo did not succeed"""

    pass


class LanguageNotSupportedError(Exception):
    """The given language was not supported by the PreCommitHooks abstraction"""

    pass


class LanguagePreCommitConfig(pydantic.BaseModel):
    """
    A configuration model for a supported pre-commit-configurable language.
    """

    language: str
    config_data: str
    version: str


class ExecuteResult(pydantic.BaseModel):
    """
    The results of calling execute_hooks
    """

    successful: bool
    error: Optional[str] = None


class InstallResult(pydantic.BaseModel):
    """
    The results of calling install
    """

    successful: bool
    version_installed: str


class PreCommitAbstraction:
    """
    Abstracts the configuring and execution of pre-commit.
    """

    def __init__(
        self,
        command_timeout_seconds: int,
        data_loader: Callable[[str], str],
        ignored_file_patterns: list[str],
    ):
        self.command_timeout_seconds = command_timeout_seconds
        self.data_loader = data_loader
        self.ignored_file_patterns = ignored_file_patterns

    def _get_language_config(self, language: str) -> LanguagePreCommitConfig:
        """
        Calculates a hash of the pre-commit file for the given language to be used as part
        of the overall installed configuration.
        :param language: The language specified
        :raises LanguageNotSupportedError if the associated pre-commit file for the language is not found
        :return: LanguagePreCommitConfig - A configuration model containing the language,
        config file data, and a versioning hash of the file contents.
        """
        try:
            config_data = self._calculate_combined_configuration(language)

            version = hashlib.md5(
                config_data.encode("utf8"), usedforsecurity=False
            ).hexdigest()
            return LanguagePreCommitConfig(
                language=language, config_data=config_data, version=version
            )
        except ValueError:
            raise LanguageNotSupportedError(
                f"Language '{language}' is currently unsupported"
            )

    def _calculate_combined_configuration(self, language: str) -> str:
        """
        Combine elements of our configuration for the specified language along with
        repo settings like .secureliignore and future overrides
        :param language: The language to load the configuration for as a basis for
        the combined configuration
        :return: The combined configuration data
        """
        slugified_language = slugify(language)
        config_data = self.data_loader(f"{slugified_language}-pre-commit.yaml")
        if not self.ignored_file_patterns:
            return config_data

        config = yaml.safe_load(config_data)

        combined_ignore_pattern = combine_patterns(self.ignored_file_patterns)

        # note: don't have to check for None here because None is only possible if we had 0 patterns,
        # which we guarded against above already.
        config["exclude"] = combined_ignore_pattern

        return yaml.dump(config)

    def version_for_language(self, language: str) -> str:
        """
        Calculates a hash of the pre-commit file for the given language to be used as part
        of the overall installed configuration.
        :param language: The language specified
        :raises LanguageNotSupportedError if the associated pre-commit file for the language is not found
        :return: The hash of the language-pre-commit.yaml file found in the resources
        matching the given language.
        """
        language_config = self._get_language_config(language)
        return language_config.version

    def install(self, language: str) -> InstallResult:
        """
        Identifies the template we hold for the specified language, writes it, installs it, and cleans up
        :param language: The language to identify a template for
        :raises LanguageNotSupportedError if a pre-commit template cannot be found for the specified language
        :raises InstallFailedError if the template was found, but an error occurred installing it
        """

        path_to_pre_commit_file = Path(".pre-commit-config.yaml")

        # Raises a LanguageNotSupportedError if language doesn't resolve to a yaml file
        language_config = self._get_language_config(language)

        with open(path_to_pre_commit_file, "w") as f:
            f.write(language_config.config_data)

        completed_process = subprocess.run(["pre-commit", "install"])
        if completed_process.returncode != 0:
            raise InstallFailedError(
                f"Installing the pre-commit script for {language} failed"
            )

        return InstallResult(successful=True, version_installed=language_config.version)

    def execute_hooks(
        self, all_files: bool = False, hook_id: Optional[str] = None
    ) -> ExecuteResult:
        """
        Execute the configured hooks against the repository, either against your staged changes
        or all the files in the repo
        :param all_files: True if we want to scan all files, default to false, which only
        scans our staged changes we're about to commit
        :param hook_id: A specific hook to run. If None, all hooks will be run
        :return: ExecuteResult, indicating success or failure.
        """
        subprocess_args = ["pre-commit", "run", "--show-diff-on-failure"]
        if all_files:
            subprocess_args.append("--all-files")

        if hook_id:
            subprocess_args.append(hook_id)

        completed_process = subprocess.run(subprocess_args)
        if completed_process.returncode != 0:
            return ExecuteResult(
                successful=False,
                error="Some issues were encountered during the scan. Check above for more info.",
            )
        else:
            return ExecuteResult(successful=True)
