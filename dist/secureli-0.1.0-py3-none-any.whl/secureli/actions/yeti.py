from secureli.abstractions.echo import EchoAbstraction, Color


class YetiAction:
    """
    An action responsible for displaying the Securyeti ASCII art in the terminal during the `yeti` command.
    """

    def __init__(self, yeti_data: str, echo: EchoAbstraction):
        self.yeti_data = yeti_data
        self.echo = echo

    def print_yeti(self, color: Color):
        """
        Use the provided color and echo service to print the Securyeti to the terminal
        :param color:
        :return:
        """
        self.echo.print(self.yeti_data, color=color, bold=True)
