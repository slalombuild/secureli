from pathlib import Path

from secureli.abstractions.echo import EchoAbstraction
from secureli.repositories.secureli_config import SecureliConfigRepository
from secureli.services.language_analyzer import LanguageAnalyzerService
from secureli.services.language_support import LanguageSupportService
from secureli.actions.action import Action


class InitializerAction(Action):
    """The action for the SeCureLI `init` command, orchestrating services and outputs results"""

    def __init__(
        self,
        echo: EchoAbstraction,
        language_analyzer: LanguageAnalyzerService,
        language_support: LanguageSupportService,
        secureli_config: SecureliConfigRepository,
    ):
        super().__init__(secureli_config, language_support, language_analyzer, echo)

    def initialize_repo(self, folder_path: Path, reset: bool, always_yes: bool):
        """
        Initializes SeCureLI for the specified folder path
        :param folder_path: The folder path to initialize the repo for
        :param reset: If true, disregard existing configuration and start fresh
        :param always_yes: Assume "Yes" to all prompts
        """
        self.verify_install(folder_path, reset, always_yes)
