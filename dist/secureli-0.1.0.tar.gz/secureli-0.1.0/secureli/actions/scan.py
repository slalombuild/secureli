from pathlib import Path
from typing import Optional

from secureli.abstractions.echo import EchoAbstraction
from secureli.repositories.secureli_config import SecureliConfigRepository
from secureli.services.language_analyzer import LanguageAnalyzerService
from secureli.services.language_support import LanguageSupportService
from secureli.services.scanner import ScanMode, ScannerService
from secureli.actions.action import VerifyOutcome, Action


class ScanAction(Action):
    """The action for the secureli `scan` command, orchestrating services and outputs results"""

    """Any verification outcomes that would cause us to not proceed to scan."""
    halting_outcomes = [
        VerifyOutcome.INSTALL_FAILED,
        VerifyOutcome.INSTALL_CANCELED,
    ]

    def __init__(
        self,
        echo: EchoAbstraction,
        language_analyzer: LanguageAnalyzerService,
        language_support: LanguageSupportService,
        scanner: ScannerService,
        secureli_config: SecureliConfigRepository,
    ):
        super().__init__(secureli_config, language_support, language_analyzer, echo)
        self.scanner = scanner
        self.echo = echo

    def scan_repo(
        self,
        folder_path: Path,
        scan_mode: ScanMode,
        always_yes: bool,
        specific_test: Optional[str] = None,
    ):
        """
        Scans the given directory, or offers to go through initialization if that has not
        been completed yet. Also detects if we're out of date with SeCureLI's config
        for the language and offers to upgrade (though continues on if the user says no)
        :param folder_path: The folder path to initialize the repo for
        :param scan_mode: How we should scan the files in the repo (i.e. staged only or all)
        :param always_yes: Assume "Yes" to all prompts
        :param specific_test: If set, limits scanning to the single pre-commit hook.
        Otherwise, scans with all hooks.
        """
        verify_result = self.verify_install(folder_path, False, always_yes)

        if verify_result.outcome in self.halting_outcomes:
            return

        scan_result = self.scanner.scan_repo(scan_mode, specific_test)
        if not scan_result.successful:
            self.echo.error(scan_result.error or "Unknown error during scan")
        else:
            self.echo.print("Scan executed successfully and detected no issues!")
