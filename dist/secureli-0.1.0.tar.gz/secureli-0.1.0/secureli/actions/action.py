from abc import ABC
from enum import Enum
from pathlib import Path
from typing import Optional

import pydantic

from secureli.abstractions.echo import EchoAbstraction, Color
from secureli.abstractions.pre_commit import (
    InstallFailedError,
    LanguageNotSupportedError,
)
from secureli.repositories.secureli_config import (
    SecureliConfig,
    SecureliConfigRepository,
)
from secureli.services.language_analyzer import LanguageAnalyzerService, AnalyzeResult
from secureli.services.language_support import LanguageSupportService


class VerifyOutcome(str, Enum):
    INSTALL_CANCELED = "install-canceled"
    INSTALL_FAILED = "install-failed"
    INSTALL_SUCCEEDED = "install-succeeded"
    UPGRADE_CANCELED = "upgrade-canceled"
    UPGRADE_SUCCEEDED = "upgrade-succeeded"
    UPGRADE_FAILED = "upgrade-failed"
    UP_TO_DATE = "up-to-date"


class VerifyResult(pydantic.BaseModel):
    """
    The outcomes of performing verification. Actions can use these results
    to decide whether to proceed with their post-initialization actions or not.
    """

    outcome: VerifyOutcome
    config: Optional[SecureliConfig] = None
    analyze_result: Optional[AnalyzeResult] = None


class Action(ABC):
    """The base Action class for any action that can analyze, install and update SeCureLI's configuration."""

    def __init__(
        self,
        secureli_config: SecureliConfigRepository,
        language_support: LanguageSupportService,
        language_analyzer: LanguageAnalyzerService,
        echo: EchoAbstraction,
    ):
        self.echo = echo
        self.language_analyzer = language_analyzer
        self.language_support = language_support
        self.secureli_config = secureli_config

    def verify_install(
        self, folder_path: Path, reset: bool, always_yes: bool
    ) -> VerifyResult:
        """
        Installs, upgrades or verifies the current SeCureLI installation
        :param folder_path: The folder path to initialize the repo for
        :param reset: If true, disregard existing configuration and start fresh
        :param always_yes: Assume "Yes" to all prompts
        """

        config = SecureliConfig() if reset else self.secureli_config.load()

        if not config.overall_language or not config.version_installed:
            return self._install_secureli(folder_path, always_yes)
        else:
            available_version = self.language_support.version_for_language(
                config.overall_language
            )
            if available_version != config.version_installed:
                return self._upgrade_secureli(config, available_version, always_yes)

            self.echo.print(
                f"SeCureLI is installed and up-to-date (language = {config.overall_language})"
            )
            return VerifyResult(
                outcome=VerifyOutcome.UP_TO_DATE,
                config=config,
            )

    def _upgrade_secureli(
        self, config: SecureliConfig, available_version: str, always_yes: bool
    ) -> VerifyResult:
        """
        Installs SeCureLI into the given folder path and returns the new configuration
        :param config: The existing configuration for SeCureLI
        :param available_version: The new version we're upgrading to
        :param always_yes: Assume "Yes" to all prompts
        :return: The new SecureliConfig after upgrade or None if upgrading did not complete
        """
        self.echo.print(
            f"The version installed is {config.version_installed}, but the latest is {available_version}"
        )
        response = always_yes or self.echo.confirm(
            "Upgrade now?",
            default_response=True,
        )
        if not response:
            self.echo.warning("User canceled upgrade process")
            return VerifyResult(
                outcome=VerifyOutcome.UPGRADE_CANCELED,
                config=config,
            )

        try:
            version_installed = self.language_support.apply_support(
                config.overall_language
            )

            # Update config with new version installed and save it
            config.version_installed = version_installed
            self.secureli_config.save(config)
            self.echo.print("SeCureLI has been upgraded successfully")
            return VerifyResult(
                outcome=VerifyOutcome.UPGRADE_SUCCEEDED,
                config=config,
            )
        except InstallFailedError:
            self.echo.error("SeCureLI could not be upgraded due to an error")
            return VerifyResult(
                outcome=VerifyOutcome.UPGRADE_FAILED,
                config=config,
            )

    def _install_secureli(self, folder_path: Path, always_yes: bool) -> VerifyResult:
        """
        Installs SeCureLI into the given folder path and returns the new configuration
        :param folder_path: The folder path to initialize the repo for
        :param always_yes: Assume "Yes" to all prompts
        :return: The new SecureliConfig after install or None if installation did not complete
        """
        self.echo.print("SeCureLI has not been setup yet.")
        response = always_yes or self.echo.confirm(
            "Initialize SeCureLI now?",
            default_response=True,
        )
        if not response:
            self.echo.error("User canceled install process")
            return VerifyResult(
                outcome=VerifyOutcome.INSTALL_CANCELED,
            )

        try:
            analyze_result = self.language_analyzer.analyze(folder_path)

            if analyze_result.skipped_files:
                self.echo.warning(
                    f"Skipping {len(analyze_result.skipped_files)} file(s):"
                )
            for skipped_file in analyze_result.skipped_files:
                self.echo.warning(f"- {skipped_file.error_message}")

            if not analyze_result.language_proportions:
                raise ValueError("No supported languages found in current repository")

            self.echo.print("Detected the following languages:")
            for language, percentage in analyze_result.language_proportions.items():
                self.echo.print(
                    f"- {language}: {percentage:.0%}", color=Color.MAGENTA, bold=True
                )
            overall_language = list(analyze_result.language_proportions.keys())[0]
            self.echo.print(f"Overall Detected Language: {overall_language}")

            version_installed = self.language_support.apply_support(overall_language)

        except (ValueError, LanguageNotSupportedError, InstallFailedError) as e:
            self.echo.error(
                f"SeCureLI could not be installed due to an error: {str(e)}"
            )
            return VerifyResult(
                outcome=VerifyOutcome.INSTALL_FAILED,
            )

        config = SecureliConfig(
            overall_language=overall_language,
            version_installed=version_installed,
        )
        self.secureli_config.save(config)
        self.echo.print(
            f"SeCureLI has been installed successfully (language = {config.overall_language})"
        )
        return VerifyResult(
            outcome=VerifyOutcome.INSTALL_SUCCEEDED,
            config=config,
            analyze_result=analyze_result,
        )
